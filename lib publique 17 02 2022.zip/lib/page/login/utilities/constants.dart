class Constants {
  static String statues = "statuses";
  static String count = "count";
}
