

import 'dart:ui';

class   Couleurs {

  static Color defaultColorsSplashBackground =  Color(0xff393e25) ;
  static Color buttonPageRetaurantColors =  Color(0xffc8f806) ;


  static Color black =  Color(0xff000000) ;
}